import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;



public class ClienteMain { //ClienteMain
	public static void main(String[] args) {
		Banco banco;
		Registry registry;
		try {
			registry = LocateRegistry.getRegistry("127.0.0.1", 2002);
			//registry = LocateRegistry.getRegistry("172.16.1.184", 2002);
			banco = (Banco) registry.lookup("Banco");
			banco.menu();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

