import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class BancoImplementacao extends UnicastRemoteObject implements Banco{
	private static final long serialVersionUID = -2924000165294588367L;
	
	List<Conta> listConta = new ArrayList<Conta>();
	
	protected BancoImplementacao() throws RemoteException {
		super();
	}
	
	@Override
	public String menu() throws RemoteException{
		return Views.MENU_PRINCIPAL();
	}
	@Override	
	public boolean acessarConta(String Dados[]) throws RemoteException{
		if(listConta.isEmpty())
			return false;
		else {
			for(int i=0; i<listConta.size(); i++ ) {
				if(listConta.get(i).getNome().equals(Dados[0])) {
					if(listConta.get(i).getSenha().equals(Dados[1]))
						return true;
					else {
						return false;
					}
				}else{
					return false;
				}
			}
			return false;
		}
	}
	
	@Override
	public boolean abrirConta(String Dados[]) throws RemoteException{
		if(listConta.isEmpty()){
			abrir(Dados);
			return true;
		}else {
			for(int i=0; i<listConta.size(); i++ ) {
				if(listConta.get(i).getNome().equals(Dados[0])) {
					return false;
				}else{
					if(i==listConta.size()-1) {
						abrir(Dados);
						return true;
					}
				}
			}
		}
		return true;
	}
	
	public void abrir(String Dados[]) throws RemoteException{
		System.out.println("Abrir");
		Cliente cliente = new Cliente();
		System.out.println("New Cliente");
		cliente.CriarCliente(Dados);
		System.out.println("Criou cliente");
		Conta contaCliente = new Conta(cliente, Dados[1]);
		System.out.println("Antes de add na lista");
		listConta.add(contaCliente);
	}
	
	@Override
	public String exibirConta(String nome) throws RemoteException{
		if(listConta.isEmpty()) {
			return "Conta inexistente!";
		}else {
			for(int i=0; i<listConta.size(); i++ ) {
				if(listConta.get(i).getNome().equals(nome)) {
					return listConta.get(i).exibeDados();
				}else{
					return "Conta inexistente!";
				}
			}
		}
		return null;
	}
	
	public String todasContas() throws RemoteException{
		String aux = "";
		for(int i=0; i<listConta.size(); i++ ) {
			aux += this.listConta.get(i).exibeDados() + "\n";
		}
		return aux;
	}
	
	@Override
	public boolean existeConta(String nome) throws RemoteException{
		if(listConta.isEmpty()) {
			return false;
		}else {
			for(int i=0; i<listConta.size(); i++) {
				if(listConta.get(i).getNome().equals(nome)) {
					return true;
				}else{
					if(i == listConta.size()-1)
						return false;
				}
			}
		}
		return false;		
	}
	
	@Override
	public String depositar(String nome, Double valor) throws RemoteException{
		for(int i=0; i<listConta.size(); i++ ) {
			if(listConta.get(i).getNome().equals(nome)) {
				listConta.get(i).depositar(valor);
				return "Deposito realizado com sucesso!";
			}
		}
		return "";
	}
	
	@Override
	public String saque(String nome, Double valor) throws RemoteException{
		for(int i=0; i<listConta.size(); i++ ) {
			if(listConta.get(i).getNome().equals(nome)) {
				return listConta.get(i).saque(valor);
			}
		}
		return "";
	}
	
	@Override
	public double saldo(String nome) throws RemoteException{
		for(int i=0; i<listConta.size(); i++ ) {
			if(listConta.get(i).getNome().equals(nome)) {
				return listConta.get(i).getSaldo();
			}
		}
		return 0;
	}
	
	@Override
	public String transferir(String remetente, String destino, Double valor) throws RemoteException{
		if((saldo(remetente)-valor) <= 0) return "Saldo Insuficiente";
		else {
			depositar(destino, valor);
			saque(remetente, valor);
			return "Trasnferencia realizada com sucesso";
		}
	}
}
