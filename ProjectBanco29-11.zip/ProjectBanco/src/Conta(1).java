
public class Conta {
	private int numero;
	private String senha;
	private double saldo;
	private boolean status;
	private Cliente cliente;

	private String log = "";

	public Conta(Cliente cliente){
		//this.numero = numero;
		this.cliente = cliente;
		//this.senha = senha;
		this.saldo = 0;
		this.status = true;	
	}
	
	public void depositar(double valor) {
		this.saldo += valor;
	}
	
	public void saque(double valor) {
		if(saldo == 0) {
			System.out.println("Saldo insuficiente!");
		}else {
			this.saldo -= valor;
			System.out.println("Saque realizado!");
		}
	}
	
	public double getSaldo() {
		return this.saldo;
	}
	
	public int numero() {
		return this.numero;
	}
	public String getNome(){
		String aux = this.cliente.getNome();
		return aux;
	}

}
