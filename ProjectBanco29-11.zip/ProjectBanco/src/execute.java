
public class execute {
	public void main() {
		int n;
		n = Integer.parseInt(Views.SC.next());
	}
}
