import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Banco extends Remote{
	public void insereLista(Conta conta)throws RemoteException;
	public String abrirConta() throws RemoteException;
	public void exibirContas() throws RemoteException;
	public String menu() throws RemoteException;
	public String menuOp(int n) throws RemoteException;
}