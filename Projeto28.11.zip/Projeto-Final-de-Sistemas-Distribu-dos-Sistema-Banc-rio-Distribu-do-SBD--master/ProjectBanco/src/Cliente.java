
public class Cliente {
	private String Nome, email;
	private int cpf, telefone;
	
	public void CriarCliente() {
		String[] Dados;
		Dados = Views.CRIAR_CONTA();
		
		this.Nome = Dados[0];
		//this.cpf = Integer.parseInt(Dados[1]);
		//this.telefone = Integer.parseInt(Dados[2]);
		//this.email = Dados[3];
		//this.Nome = nome;
		
		
	}
	public void exibirDadosCliente() {
		System.out.print("Que otimo, voce ja eh nosso cliente!\n");
	    System.out.print("Informe os seguintes dados para acessar sua conta.\n\n");
	    System.out.printf("Nome: %s\n", this.Nome);
	    System.out.printf("CPF: %d\n", this.cpf);
	    System.out.printf("Email: %s\n", this.email);
	    System.out.printf("Telefone: %d", this.telefone);
	}
	
	public String getNome() {
		return this.Nome;
	}
	
	
}
