import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Banco extends Remote{
	public void insereLista(Conta conta)throws RemoteException;
	public void abrirConta() throws RemoteException;
	public void exibirContas() throws RemoteException;
	public void menu() throws RemoteException;
}