import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class BancoImplementacao extends UnicastRemoteObject implements Banco{
	private static final long serialVersionUID = -2924000165294588367L;
	
	int conta;
	String cliente;
	List<Conta> listConta = new ArrayList<Conta>();
	protected BancoImplementacao() throws RemoteException {
		super();
	}
	@Override
	public void menu() throws RemoteException{
		String n, nome;
		Views.MENU_PRINCIPAL();
		n = Views.SC.next();
		Scanner sc = new Scanner(System.in);
		
		while(n!="0") {
			switch(n) {
				case "1":	//Abrir conta
					abrirConta();
					break;
				case "2":	//Exibe as contas
					exibirContas();
					break;
				case "3":{	//Depositar
					nome = sc.next();
					for(int i=0; i<listConta.size(); i++ ) {
						if(listConta.get(i).getNome().equals(nome)) {
							listConta.get(i).depositar(Double.parseDouble(sc.next()));
							System.out.println("Deposito Realizado!");
						}else {
							if(i==listConta.size()-1)
								System.out.println("Conta inexistente!");
							
						}
					}
					/*for(Conta c : listConta) {
						if(c.getNome().equals(nome)) {
							c.depositar(Double.parseDouble(sc.next()));
							System.out.println("Deposito Realizado!");
						}else {
							if(c.equals(null))
								System.out.println("Conta inexistente!");
							
						}
					}*/
					break;
				}
				case "4":{	//Saque
					nome = sc.next();
					for(Conta c : listConta) {
						if(c.getNome().equals(nome)) {
							c.saque(Double.parseDouble(sc.next()));
							break;
						}else {
							System.out.println("Conta inexistente!");
							break;
						}
					}
					break;
				}
			}
			Views.MENU_PRINCIPAL();
			n = Views.SC.next();
		}
		
	}
	
	@Override
	public void abrirConta() throws RemoteException{
		Cliente cliente = new Cliente();
		cliente.CriarCliente();
		Conta contaCliente = new Conta(cliente);
		insereLista(contaCliente);
	}
	
	@Override
	public void insereLista(Conta conta) throws RemoteException{
		listConta.add(conta);
	}
	@Override
	public void exibirContas() throws RemoteException{
		for(Conta c : listConta) {
			System.out.println(c.getNome());
			System.out.println(c.getSaldo());
		}
	}
	
}
